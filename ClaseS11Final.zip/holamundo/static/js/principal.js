alert("Bienvenido a mi pagina")
console.log("JS OK")