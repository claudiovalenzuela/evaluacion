from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib import messages
from django.contrib.auth import login, logout

# Create your views here.


def vista_registro(request):
    if request.method == "POST":
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Usuario creado correctamente")
            return redirect("anuncios:lista")
    else:
        form = UserCreationForm()
    return render(request, "usuarios/registro.html", {"form": form})


def vista_login(request):
    if request.method == "POST":
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            usuario = form.get_user()
            login(request, usuario)
            messages.success(
                request, f"Usuario {usuario} inicio sesion correctamente")
            return redirect("anuncios:lista")
    else:
        form = AuthenticationForm()
    return render(request, "usuarios/login.html", {"form": form})


def vista_logout(request):
    if request.method == "POST":
        usuario = request.user
        logout(request)
        messages.success(
            request, f"Usuario {usuario} cerro sesion correctamente")
        return redirect("anuncios:lista")
