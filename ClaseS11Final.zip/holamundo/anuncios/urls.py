from django.urls import path
from . import views


app_name = "anuncios"

urlpatterns = [
    path('', views.lista_anuncios, name="lista"),
    path('<slug:slug>', views.pagina_anuncio, name="detalle"),
]
