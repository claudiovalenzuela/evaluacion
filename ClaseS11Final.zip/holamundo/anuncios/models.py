from django.db import models

# Create your models here.


class Anuncio(models.Model):
    titulo = models.CharField(max_length=75)
    cuerpo = models.TextField()
    slug = models.SlugField(max_length=200, default='none')
    fecha = models.DateTimeField(auto_now_add=True)
    imagen = models.ImageField(default='sin_imagen.png', blank=True)

    def __str__(self):
        return self.titulo
