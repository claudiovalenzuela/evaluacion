from django.shortcuts import render
from . models import Anuncio
# Create your views here.


def lista_anuncios(request):
    anuncios = Anuncio.objects.all()
    return render(request, 'anuncios/lista_anuncios.html', {'anuncios': anuncios})


def pagina_anuncio(request, slug):
    anuncio = Anuncio.objects.get(slug=slug)
    return render(request, 'anuncios/anuncio.html', {'anuncio': anuncio})
