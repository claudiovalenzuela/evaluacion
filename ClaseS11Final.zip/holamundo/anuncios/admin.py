from django.contrib import admin
from . models import Anuncio
# Register your models here.
admin.site.register(Anuncio)
