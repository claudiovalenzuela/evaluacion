# from django.http import HttpResponse
from django.shortcuts import render


def pagina_inicio(request):
    # return HttpResponse("Hola Mundo. Estamos en la pagina de inicio.")
    return render(request, 'inicio.html')


def pagina_acerca_de(request):
    # return HttpResponse("Estamos en la pagina de acerca de.")
    return render(request, 'acerca.html')
